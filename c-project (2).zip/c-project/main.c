
#include <stdio.h>

struct Organisation {
    char name[50];
    char location[50];
    int employees;
};

int main() {
    struct Organisation org[5];
    int n, i, choice, num;

    printf("How many organisations (3-5)? ");
    scanf("%d", &n);

    

    for (i = 1; i <= n; i++) {
        printf("\nOrganisation %d\n", i );

        printf("Enter name: ");
        scanf(" %49[^\n]", org[i].name);

        printf("Enter location: ");
        scanf(" %49[^\n]", org[i].location);

        printf("Enter number of employees: ");
        scanf("%d", &org[i].employees);
    }

    do {
        printf("\n1. Show all organisations");
        printf("\n2. Search organisation by number");
        printf("\n0. Exit");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            for (i = 0; i < n; i++) {
                printf("\nName: %s", org[i].name);
                printf("\nLocation: %s", org[i].location);
                printf("\nEmployees: %d\n", org[i].employees);
            }
        }
        else if (choice == 2) {
            printf("Enter organisation number: ");
            scanf("%d", &num);

            if (num >= 1 && num <= n) {
                i = num ;
                printf("\nName: %s", org[i].name);
                printf("\nLocation: %s", org[i].location);
                printf("\nEmployees: %d\n", org[i].employees);
            }
            else {
                printf("Invalid organisation number!\n");
            }
        }
        else if (choice != 0) {
            printf("Invalid choice!\n");
        }

    } while (choice != 0);

    return 0;
}
